package pacoteB;

public class ClasseC {

	public void metodoPacoteB() {
		System.out.println("Classe C.");
	}
	
}
