package pacoteA;

public class ClasseB extends ClasseA {

	@Override
	public void metodoPacoteA() {
		System.out.println("Classe B.");
	}
	
}
