package pacoteA;

public class ClasseA {

	public void metodoPacoteA() {
		System.out.println("Classe A.");
	}
	
}
